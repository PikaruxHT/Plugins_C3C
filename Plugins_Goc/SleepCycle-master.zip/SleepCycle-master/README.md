# SleepCycle
Plugin for c3c-0x chatbot: https://github.com/c3cbot/c3c-0x.
Commands: sleep and remind_sleep
